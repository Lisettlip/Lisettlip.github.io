// ================================
// Waltz – Game Logic Core
// ================================

// ---- KONSTANTID ----
const POINTS_PER_COLLECT = 10;
const COLLECT_DISTANCE = 30; // meetrites

// ---- HAVERSINE DISTANCE CHECK ----
function canCollect(userLat, userLng, objectLat, objectLng) {
    const R = 6371000; // Maa raadius meetrites

    const toRad = (deg) => deg * Math.PI / 180;

    const dLat = toRad(objectLat - userLat);
    const dLng = toRad(objectLng - userLng);

    const lat1 = toRad(userLat);
    const lat2 = toRad(objectLat);

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1) * Math.cos(lat2) *
        Math.sin(dLng / 2) * Math.sin(dLng / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    const distance = R * c;

    return distance < COLLECT_DISTANCE;
}

// ---- OBJEKTI KOGUMISE LOOGIKA ----
function collectObject({
    userLat,
    userLng,
    objectLat,
    objectLng,
    alreadyCollected
}) {
    if (alreadyCollected) {
        return {
            success: false,
            reason: "ALREADY_COLLECTED"
        };
    }

    if (!canCollect(userLat, userLng, objectLat, objectLng)) {
        return {
            success: false,
            reason: "TOO_FAR"
        };
    }

    return {
        success: true,
        points: POINTS_PER_COLLECT
    };
}

// ================================
// TESTID (käivituvad kohe)
// ================================

console.log("TEST 1 – Lähedal (true):");
console.log(
    collectObject({
        userLat: 59.4370,
        userLng: 24.7536,
        objectLat: 59.4371,
        objectLng: 24.7536,
        alreadyCollected: false
    })
);

console.log("TEST 2 – Liiga kaugel (TOO_FAR):");
console.log(
    collectObject({
        userLat: 59.4370,
        userLng: 24.7536,
        objectLat: 59.4374,
        objectLng: 24.7536,
        alreadyCollected: false
    })
);

console.log("TEST 3 – Juba kogutud (ALREADY_COLLECTED):");
console.log(
    collectObject({
        userLat: 59.4370,
        userLng: 24.7536,
        objectLat: 59.4371,
        objectLng: 24.7536,
        alreadyCollected: true
    })
);